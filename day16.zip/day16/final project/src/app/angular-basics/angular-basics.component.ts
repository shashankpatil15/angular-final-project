import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-basics',
  templateUrl: './angular-basics.component.html',
  styleUrls: ['./angular-basics.component.css']
})
export class AngularBasicsComponent implements OnInit {

  title = 'Angular 5 @ Softedge'; //what to display
  
    colors=["ORANGE","MAGENTA","RED","GREEN"];
  
    show=true;
  
    name={fname:'Pradeep',lname:'Chinchole'};
  
    day=1;
  
    showHide(){
      this.show=!this.show;
    }
  ngOnInit() {
  }

}
