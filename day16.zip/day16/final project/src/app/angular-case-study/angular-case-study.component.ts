import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-case-study',
  templateUrl: './angular-case-study.component.html',
  styleUrls: ['./angular-case-study.component.css']
})
export class AngularCaseStudyComponent implements OnInit {

title="Angular 5 User Managment Application";

  constructor() { }

  ngOnInit() {
  }

}
