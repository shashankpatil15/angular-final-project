import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-technologies',
  templateUrl: './technologies.component.html',
  styleUrls: ['./technologies.component.css']
})
export class TechnologiesComponent implements OnInit {

  title="Today's 5 top Technologies";
  
  technologies:Array<any>;
  
  constructor() { 
  console.log("Technology Componetn creaated...");
   }
  
    ngOnInit() {
     console.log("Technology Componetn initialized...");
     this.technologies=[
      {id:1,name:"Angular ",likes:0,dislikes:0},
      {id:2,name:"Big Data",likes:0,dislikes:0},
      {id:3,name:"Python",likes:0,dislikes:0},
      {id:4,name:"Amazon Web Services",likes:0,dislikes:0},
      {id:5,name:"Java",likes:0,dislikes:0},
      ];
     }
  
  
     incrementLikes(t){
      t.likes++;
    }
    
    incrementDislikes(t){
      t.dislikes++;
    }
  

}
