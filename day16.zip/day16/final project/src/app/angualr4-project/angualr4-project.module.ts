import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Angualr4ProjectRoutingModule } from './angualr4-project-routing.module';

@NgModule({
  imports: [
    CommonModule,
    Angualr4ProjectRoutingModule
  ],
  declarations: []
})
export class Angualr4ProjectModule { }
