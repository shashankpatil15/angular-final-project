import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-custom-directives',
  templateUrl: './custom-directives.component.html',
  styleUrls: ['./custom-directives.component.css']
})
export class CustomDirectivesComponent  {

title="CustomDirective Demo";


fcolors=["RED","GREEN","BLUE","MAGENTA","BROWN"];
bcolors=["CYAN","WHEAT","YELLOW","PINK","ORANGE"];


@Input()
color="hi";


show=true;

hide=true;

fcolor="";

bcolor="";

  constructor() { 
  console.log("###### CustomDirectiveComponent Created #########")
  }

  ngOnInit() {
    console.log("###### CustomDirectiveComponent Initialized #########")
  }
  
  ngOnChanges() {
    console.log("###### CustomDirectiveComponent ngOnChanges #########")
  }
  
  ngDoCheck() {
    console.log("###### CustomDirectiveComponent ngOnDoCheck  #########")
  }

  ngAfterContentInit(){
    console.log("###### CustomDirectiveComponent ngAfterContentInit  #########")
    
  }

  ngAfterContentChecked(){
    console.log("###### CustomDirectiveComponent ngAfterContentChecked  #########")
   }


   ngAfterViewInit(){
    console.log("###### CustomDirectiveComponent ngAfterViewInit  #########")
    
   }

   ngAfterViewChecked(){
    console.log("###### CustomDirectiveComponent ngAfterViewChecked  #########")
    }

  
  ngOnDestroy() {
    console.log("###### CustomDirectiveComponent ngOnDestroy  #########")
  }
  




}
