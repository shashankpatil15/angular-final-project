import { Component, OnInit } from '@angular/core';
import { PhotosService } from '../service/photos.service';

@Component({
  selector: 'app-photos',
  templateUrl: './photos.component.html',
  styleUrls: ['./photos.component.css']
})
export class PhotosComponent implements OnInit {

  
  
  title="All Photos";
  photos:Array<any>;
  message="";
  
  
    constructor(private ps:PhotosService) {
      console.log("PhotosComponent  created.....");
      
    
    }
  
    ngOnInit() {
      console.log("PhotosComponent initialized.....");
      this.getAllPhotos()
    }
  
  
    getAllPhotos(){
      
      this.ps.getAllPhotos()
             .subscribe(response=>this.photos=response,error=>this.message=error);
        }
  
          

}
