import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'orderBy'
})
export class OrderByPipe implements PipeTransform {

  transform(array: Array<any>, field?:string,descending?:boolean): Array<any>
   {
    console.log("In orderBy transform...");
  
    if(field==undefined || field=='id')
    array.sort((e1,e2)=>e1.id-e2.id);
    else if(field=='name')
    array.sort((e1,e2)=>e1.name.localeCompare(e2.name));
    else if(field=='city')
    array.sort((e1,e2)=>e1.city.localeCompare(e2.city));
    else if(field=='pan')
    array.sort((e1,e2)=>e1.pan.localeCompare(e2.pan));
    else if(field=='mobile')
    array.sort((e1,e2)=>e1.mobile.localeCompare(e2.mobile));
    else if(field=='age')
    array.sort((e1,e2)=>e1.age-e2.age);
    else if(field=='dob')
    array.sort((e1,e2)=>e1.dob.getTime()-e2.dob.getTime());
    else if(field=='salary')
    array.sort((e1,e2)=>e1.salary-e2.salary);
    
     if(descending)
    array.reverse();
    return array;
  }
}
