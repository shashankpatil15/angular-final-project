import { NgHideDirective } from './ng-hide.directive';

describe('NgHideDirective', () => {
  it('should create an instance', () => {
    const directive = new NgHideDirective();
    expect(directive).toBeTruthy();
  });
});
