import { Directive,Input } from '@angular/core';
import { ElementRef } from '@angular/core';
import { Renderer2 } from '@angular/core';

@Directive({
  selector: '[bgColor]'
})
export class BgColorDirective {

  constructor(private el:ElementRef,private r:Renderer2){
    console.log("BgColorDirective created......");
   }

  
   @Input("bgColor")
  set fgColor(color:string){
    console.log("BgColorDirective set FgColor Method  :"+color);
    this.r.setStyle(this.el.nativeElement,"background-color",color);
  } 



}
