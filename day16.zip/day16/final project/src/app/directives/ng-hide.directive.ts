import { Directive ,TemplateRef,ViewContainerRef,Input} from '@angular/core';

@Directive({
  selector: '[ngHide]'
})
export class NgHideDirective {

  constructor(private t:TemplateRef<any>,private vcr:ViewContainerRef) {
    console.log("NgHideDirective created.....")
   }

   @Input()
   set ngHide(hide:boolean){
    console.log("In NgHideDirective show method...."+hide);
    if(hide)
    this.vcr.clear();
    else
    this.vcr.createEmbeddedView(this.t);
   }

}
