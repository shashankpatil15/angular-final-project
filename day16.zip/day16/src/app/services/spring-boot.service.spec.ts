import { TestBed, inject } from '@angular/core/testing';

import { SpringBootService } from './spring-boot.service';

describe('SpringBootService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SpringBootService]
    });
  });

  it('should be created', inject([SpringBootService], (service: SpringBootService) => {
    expect(service).toBeTruthy();
  }));
});
