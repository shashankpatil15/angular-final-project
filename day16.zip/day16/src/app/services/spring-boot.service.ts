import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SpringBootService {
private baseURL="http://localhost:1212/swm/rest/employees";
  constructor(private http:HttpClient) {

    console.log("Spring Boot Service created...")
    
   }


   getAllEmployees():Observable<any>
   {
     return this.http.get(this.baseURL);
   }

   getEmployeeById(id:number):Observable<any>
   {
     return this.http.get(this.baseURL+"/"+id);
   }
   
   deleteEmployeeById(id:number):Observable<any>
   {
     return this.http.delete(this.baseURL+"/"+id);
   }
      

   updateEmployeeById(id:number,employee:any):Observable<any>
   {
     return this.http.put(this.baseURL+"/"+id,employee);
   }


   addEmployee(employee:any):Observable<any>
   {
     return this.http.post(this.baseURL,employee);
   }


   



}
