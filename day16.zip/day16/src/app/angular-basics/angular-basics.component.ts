import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-basics',
  templateUrl: './angular-basics.component.html',
  styleUrls: ['./angular-basics.component.css']
})
export class AngularBasicsComponent implements OnInit {
title="Angular 6 Basics";
colors=["RED","GREEN","BLUE"];
name={fname:"Pradeep",lname:"Chinchole"};
day=1;
show=true;
hide=false;
constructor() { 
  console.log("Angular Basics Component created...");
}
ngOnInit() {
console.log("Angular BAsics comp initialized...");
}
showHide(){
  this.hide=!this.hide;
}
}
