import { Component } from '@angular/core';

@Component({
  selector: 'app-root',//where to inject
  templateUrl: './app.component.html',//where to display
 // template: 'Hello {{title}}',
  styleUrls: ['./app.component.css']//how to display
})
export class AppComponent {
  title = 'Angular6 Softedge';//what to display
}
