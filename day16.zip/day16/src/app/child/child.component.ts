import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
title="Child Component";

message="Hello Students!!!!";


@Input()
parentMessage="Parent Message....";


@Output()
childChanged=new EventEmitter<string>();


  constructor() { }

  ngOnInit() {
  }


  sendMessageToParent(){
    console.log("Sending Message To Parent :"+this.message);
    this.childChanged.emit(this.message);
  }



}
