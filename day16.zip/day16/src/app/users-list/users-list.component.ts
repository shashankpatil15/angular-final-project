import { UsersService } from './../services/users.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-users-list',
  templateUrl: './users-list.component.html',
  styleUrls: ['./users-list.component.css'],
 // providers:[UsersService]
})
export class UsersListComponent implements OnInit {

title="Users List";
users:any;
message="";


  constructor(private us:UsersService) {
   console.log("USersList Component created......");
   }

  ngOnInit() {
    console.log("USersList Component initialized......");
   this.getAllUsers();
  }


  getAllUsers(){
    this.us.getAllUsers()
           .subscribe(response=>this.users=response,error=>this.message=error);
  } 





}
