import { Component, OnInit } from '@angular/core';
import { SpringBootService } from '../services/spring-boot.service';

@Component({
  selector: 'app-spring-boot',
  templateUrl: './spring-boot.component.html',
  styleUrls: ['./spring-boot.component.css']
})
export class SpringBootComponent implements OnInit {

title="Spring Boot CRUD App";

employees:any[];
message;
employee:any;
add=false;
save=false;




  constructor(private sbs:SpringBootService) {
    console.log("Spring Boot Comp created...");

   }

  ngOnInit() {
 console.log("Spring Boot Comp initialized...");
this.getAllEmployees();     
}


getAllEmployees(){
  this.sbs.getAllEmployees()
          .subscribe(response=>this.employees=response,error=>this.message=error);
  
  }

  getEmployee(id:number){
    this.sbs.getEmployeeById(id)
            .subscribe(response=>this.employee=response,error=>this.message=error);
    this.add=true;
    this.save=false;


  }
      

  newEmployee(){

    this.employee={id:0,
                   name:"",
                   email:"",
                  mobile:"",
                  salary:0.0,
                  dob:new Date(),
                  password:""};

this.add=false;
    this.save=true;
    
  }

  deleteEmployee(id:number){
    this.sbs.deleteEmployeeById(id)
            .subscribe(response=>this.employees=response,error=>this.message=error);
    
  }

  updateEmployee(){
    this.sbs.updateEmployeeById(this.employee.id,this.employee)
            .subscribe(response=>this.employees=response,error=>this.message=error);
    this.employee=null;
  }

  addEmployee(){
    this.sbs.addEmployee(this.employee)
            .subscribe(response=>this.employees=response,error=>this.message=error);
   this.employee=null; 
  }


      







}
