import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-technology',
  templateUrl: './technology.component.html',
  styleUrls: ['./technology.component.css']
})
export class TechnologyComponent implements OnInit {
title="Today top Technologies";

technologies=[
  {"id":1,name:"Angular",likes:0,dislikes:0},
  {"id":2,name:"Micro Services",likes:0,dislikes:0},
  {"id":3,name:"AWS",likes:0,dislikes:0},
];


incrementLikes(t){
  t.likes++;
}

incrementDislikes(t){
  t.dislikes++;
}
  constructor() { }

  ngOnInit() {
  }

}
