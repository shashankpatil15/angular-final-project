import { UsersService } from './../services/users.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-users-table',
  templateUrl: './users-table.component.html',
  styleUrls: ['./users-table.component.css'],
//  providers:[UsersService]
})
export class UsersTableComponent implements OnInit {

  title="Users Table";
users:any;
message="";


  constructor(private us:UsersService) {
   console.log("USersList Component created......");
   }

  ngOnInit() {
    console.log("USersList Component initialized......");
   this.getAllUsers();
  }


  getAllUsers(){
    this.us.getAllUsers()
           .subscribe(response=>this.users=response,error=>this.message=error);
  } 


}
