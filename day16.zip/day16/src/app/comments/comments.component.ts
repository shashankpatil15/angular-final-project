import { CommentsService } from './../services/comments.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comments',
  templateUrl: './comments.component.html',
  styleUrls: ['./comments.component.css']
})
export class CommentsComponent implements OnInit {

  title="Comments";
  comments:any;
  message="";
  
  
    constructor(private cs:CommentsService) {
     console.log("CommentsComponent created......");
     }
  
    ngOnInit() {
      console.log("CommentsComponent Component initialized......");
     this.getAllComments();
    }
  
  
    getAllComments(){
      this.cs.getAllComments()
             .subscribe(response=>this.comments=response,error=>this.message=error);
    } 
  
  
}
