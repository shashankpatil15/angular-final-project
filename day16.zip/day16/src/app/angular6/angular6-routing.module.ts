import { FormValidationComponent } from './../form-validation/form-validation.component';
import { NestedComponentsComponent } from './../nested-components/nested-components.component';
import { UsersTableComponent } from './../users-table/users-table.component';
import { UsersListComponent } from './../users-list/users-list.component';
import { PhotosComponent } from './../photos/photos.component';
import { AlbumsComponent } from './../albums/albums.component';
import { TodosComponent } from './../todos/todos.component';
import { CommentsComponent } from './../comments/comments.component';
import { PostsComponent } from './../posts/posts.component';
import { CaseStudyComponent } from './../case-study/case-study.component';
import { TechnologyComponent } from './../technology/technology.component';
import { AngularPipesComponent } from './../angular-pipes/angular-pipes.component';
import { AngularBasicsComponent } from './../angular-basics/angular-basics.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UsersComponent } from '../users/users.component';
import { CustomDirectivesComponent } from '../custom-directives/custom-directives.component';
import { SpringBootComponent } from '../spring-boot/spring-boot.component';

const routes: Routes = [
  {path:"home",component:AngularBasicsComponent},
  {path:"basics",component:AngularBasicsComponent},
  {path:"pipes",component:AngularPipesComponent},
  {path:"technologies",component:TechnologyComponent},
  {path:"custom-directives",component:CustomDirectivesComponent},
  {path:"spring-boot",component:SpringBootComponent},
  {path:"nested-comp",component:NestedComponentsComponent},
  {path:"form-validation",component:FormValidationComponent},
  {path:"casestudy",component:CaseStudyComponent,
   children:[
    {path:"users",component:UsersComponent,
    
    children:[
      {path:"list",component:UsersListComponent},
      {path:"table",component:UsersTableComponent},
     ]
    },
    {path:"users/:userId",component:UsersComponent},
   
    {path:"posts",component:PostsComponent},
   
        {path:"comments",component:CommentsComponent},
    {path:"todos",component:TodosComponent},
    {path:"albums",component:AlbumsComponent},
    {path:"photos",component:PhotosComponent}
 ]
},
  {path:"**",redirectTo:"home"},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class Angular6RoutingModule { }
