import { Angular6Module } from './angular6.module';

describe('Angular6Module', () => {
  let angular6Module: Angular6Module;

  beforeEach(() => {
    angular6Module = new Angular6Module();
  });

  it('should create an instance', () => {
    expect(angular6Module).toBeTruthy();
  });
});
