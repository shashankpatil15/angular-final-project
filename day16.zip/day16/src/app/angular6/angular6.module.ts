import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Angular6RoutingModule } from './angular6-routing.module';

@NgModule({
  imports: [
    CommonModule,
    Angular6RoutingModule
  ],
  declarations: []
})
export class Angular6Module { }
