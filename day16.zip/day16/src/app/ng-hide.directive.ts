import { Directive } from '@angular/core';

@Directive({
  selector: '[appNgHide]'
})
export class NgHideDirective {

  constructor() { }

}
