import { ActivatedRoute } from '@angular/router';
import { UsersService } from './../services/users.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css'],
//  providers:[UsersService]
})
export class UsersComponent implements OnInit {

title="User Details";
user:any;
message="";
userId=0;

  constructor(private us:UsersService,private route:ActivatedRoute) {
   console.log("USers Component created......");
   

   
  }

  ngOnInit() {

    
    this.route.params.subscribe(params=>{
      this.userId=params['userId'];
    });

  console.log("USers Component initialized......"+this.userId);
   this.getUser();
  



}


  getUser(){
    this.us.getUserByUserId(this.userId)
           .subscribe(response=>this.user=response,error=>this.message=error);
  } 


}
