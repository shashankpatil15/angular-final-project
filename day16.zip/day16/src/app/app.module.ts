import { PostsService } from './services/posts.service';
import { Angular6RoutingModule } from './angular6/angular6-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import {Ng2SearchPipeModule } from "ng2-search-filter";
import { AppComponent } from './app.component';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { GenderPipe } from './gender.pipe';
import { OrderByPipe } from './order-by.pipe';
import { TechnologyComponent } from './technology/technology.component';
import { CaseStudyComponent } from './case-study/case-study.component';
import { UsersComponent } from './users/users.component';
import { PostsComponent } from './posts/posts.component';
import { CommentsComponent } from './comments/comments.component';
import { TodosComponent } from './todos/todos.component';
import { PhotosComponent } from './photos/photos.component';
import { AlbumsComponent } from './albums/albums.component';
import { UsersListComponent } from './users-list/users-list.component';
import { UsersTableComponent } from './users-table/users-table.component';
import { UsersService } from './services/users.service';
import { SpringBootComponent } from './spring-boot/spring-boot.component';
import { NestedComponentsComponent } from './nested-components/nested-components.component';
import { FormValidationComponent } from './form-validation/form-validation.component';
import { CustomDirectivesComponent } from './custom-directives/custom-directives.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { FgColorDirective } from './fg-color.directive';
import { BgColorDirective } from './bg-color.directive';
import { NgShowDirective } from './ng-show.directive';
import { NgHideDirective } from './ng-hide.directive';
import { StudentComponent } from './student/student.component';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
  
@NgModule({
  declarations: [ //component,directve,pipe
    AppComponent, AngularBasicsComponent, AngularPipesComponent, GenderPipe, OrderByPipe, TechnologyComponent, CaseStudyComponent, UsersComponent, PostsComponent, CommentsComponent, TodosComponent, PhotosComponent, AlbumsComponent, UsersListComponent, UsersTableComponent, SpringBootComponent, NestedComponentsComponent, FormValidationComponent, CustomDirectivesComponent, ParentComponent, ChildComponent, FgColorDirective, BgColorDirective, NgShowDirective, NgHideDirective, StudentComponent, ReactiveFormComponent
  ],
  imports: [ //module
    BrowserModule,FormsModule,Ng2SearchPipeModule,Angular6RoutingModule,HttpClientModule,ReactiveFormsModule ],
  providers: [
//UsersService,
//PostsService
  ],//services
  bootstrap: [AppComponent] //components
})
export class AppModule { }
