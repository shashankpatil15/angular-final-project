import { TestBed, inject } from '@angular/core/testing';

import { CalculatorService } from './calculator.service';

describe('CalculatorService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CalculatorService]
    });
  });

  it('should be created', inject([CalculatorService], (service: CalculatorService) => {
    expect(service).toBeTruthy();
  }));

  it('should return sum of 10 and 5 as 15', inject([CalculatorService], (service: CalculatorService) => {
    expect(service.add(10,5)).toEqual(15);
  }));

  it('should return substraction  of 10 and 5 as 5', inject([CalculatorService], (service: CalculatorService) => {
    expect(service.sub(10,5)).toEqual(5);
  }));

  it('should return multiplication of 10 and 5 as 50', inject([CalculatorService], (service: CalculatorService) => {
    expect(service.mul(10,5)).toEqual(50);
  }));

  it('should return division of 10 and 5 as 2', inject([CalculatorService], (service: CalculatorService) => {
    expect(service.div(10,5)).toEqual(2);
  }));

  it('should return mpdulus of 10 and 5 as 0', inject([CalculatorService], (service: CalculatorService) => {
    expect(service.mod(10,5)).toEqual(0);
  }));



});
