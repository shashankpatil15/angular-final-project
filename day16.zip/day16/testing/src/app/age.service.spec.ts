import { TestBed, inject } from '@angular/core/testing';

import { AgeService } from './age.service';

describe('AgeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AgeService]
    });
  });

  it('should be created', inject([AgeService], (service: AgeService) => {
    expect(service).toBeTruthy();
  }));


  it('accept Age with 15 ', inject([AgeService], (service: AgeService) => {
    expect(service.acceptAge(15)).toBeFalsy();
  }));

  it('accept Age with 65 ', inject([AgeService], (service: AgeService) => {
    expect(service.acceptAge(65)).toBeFalsy();
  }));


  it('accept Age with 20 ', inject([AgeService], (service: AgeService) => {
    expect(service.acceptAge(20)).toBeTruthy();
  }));


  it('accept Age with 60 ', inject([AgeService], (service: AgeService) => {
    expect(service.acceptAge(60)).toBeTruthy();
  }));


  it('accept Age with 25 ', inject([AgeService], (service: AgeService) => {
    expect(service.acceptAge(25)).toBeTruthy();
  }));









});
